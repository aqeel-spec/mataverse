// addTwo.mjs
function addTwo(num) {
    return num + 2;
  }
  
  export { addTwo };